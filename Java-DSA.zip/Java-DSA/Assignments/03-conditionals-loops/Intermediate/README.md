# [Conditionals & Loops Video Link](https://youtu.be/ldYLYRNaucM)

## Write Java programs for the following: 

### Intermediate Java Programs
1. Factorial Program In Java
2. Calculate Electricity Bill
3. Calculate Average Of N Numbers
4. Calculate Discount Of Product
5. Calculate Distance Between Two Points 
6. Calculate Commission Percentage
7. Power In Java
8. Calculate Depreciation of Value
9. Calculate Batting Average
10. Calculate CGPA Java Program
11. Compound Interest Java Program
12. Calculate Average Marks
13. Addition Of Two Numbers
14. Sum Of N Numbers
15. Armstrong Number In Java
16. Find Ncr & Npr
17. Reverse A String In Java
18. Find if a number is palindrome or not 
19. Future Investment Value
20. HCF Of Two Numbers Program
21. LCM Of Two Numbers
22. Java Program Vowel Or Consonant 
23. Perfect Number In Java
24. Check Leap Year Or Not
25. Sum Of A Digits Of Number
26. Kunal is allowed to go out with his friends only on the even days of a given month. Write a program to count the number of days he can go out in the month of August.
27. Write a program to print the sum of negative numbers, sum of positive even numbers and the sum of positive odd numbers from a list of numbers (N) entered by the user. The list terminates when the user enters a zero.
