public class Q_26 {
    public static void main(String[] args) {
        System.out.println("Number of Days kunal can go out in the month of August are : "+(31/2));
    }
}
