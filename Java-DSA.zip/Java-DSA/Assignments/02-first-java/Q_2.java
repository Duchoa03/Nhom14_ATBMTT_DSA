import java.util.Scanner;

public class Q_2 {
    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the name : ");

        String name = input.nextLine();
        
        System.out.println("Hello " + name + " Welcome to my world!.");
    }
}